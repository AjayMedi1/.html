# CI/CD Pipeline using Jenkins, GitHub, EC2, S3

This project demonstrates a DevOps CI/CD pipeline setup using:

- Jenkins (running on AWS EC2)
- GitHub (with Webhook trigger)
- Dockerized Node.js app
- AWS S3 (for build artifact storage)

## Setup

1. Create EC2 & install Jenkins
2. Connect GitHub repo with Jenkins
3. Dockerize Node.js app
4. Push build artifacts to S3
5. Use GitHub Webhook for automation

## Architecture

*EC2 -> Jenkins -> GitHub -> Docker Build -> Push to S3*

## Output

![Jenkins Job Success](screenshots/jenkins-success.png)